package restAPIBookerTests;
import com.jayway.restassured.response.Response;
import restAPIFramework.Service;

public class TestBase {

    Service service;
    Response response;
}
