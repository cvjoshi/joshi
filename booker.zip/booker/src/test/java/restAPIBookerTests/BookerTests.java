package restAPIBookerTests;

import com.google.gson.Gson;
import org.json.JSONException;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import responsePojo.CreateBookingResponse;
import restAPIFramework.Service;

import java.io.IOException;

public class BookerTests extends TestBase{

    String firstName;
    String lastName;
    double totalPrice;
    boolean depositPaid;
    String checkinDate;
    String checkoutDate;
    String additionalNeeds;
    Service service = new Service();

    String BookingID;
    String bookerToken;

    /**
     *
     * dataSetup is used to prepare data to create booking and get all properties required
     */
    @BeforeClass
    public void dataSetUp() throws IOException{

        service.getPropValues();

        firstName = "Chidambar";
        lastName = "Joshi";
        totalPrice = 100;
        depositPaid = true;
        checkinDate = "2019-09-05";
        checkoutDate = "2019-09-06";
        additionalNeeds = "Lunch";
    }

    /*
    @Test
    public void getBookingIDsTest() {

        response = service.getBookings();

        System.out.println("Response Code" + response.getStatusCode());
        System.out.println(response.asString());
        if (response.getStatusCode() == 200) {
            System.out.println(response.asString());
            //Gson gson = new Gson();
            //String getBookings = gson.fromJson(response.asString(), Entity.class).toString();

            //System.out.println(getBookings);
        }
    }*/

    /**
     *
     * @ Test to create a booking
     */
    @Test
    public void createBookingTest() throws JSONException {
        response = service.createBooking(firstName, lastName, totalPrice, depositPaid, checkinDate, checkoutDate, additionalNeeds);

        System.out.println("Create Booking Test Starts\n");

        if (response.getStatusCode() == 200) {

            //System.out.println(response.asString());

            JSONObject jsonObj = new JSONObject(response.asString());

            System.out.println("JSON object from response");
            System.out.println(jsonObj);

            Assert.assertEquals(jsonObj.has("bookingid"),true,"Booking ID is available in response");

            Assert.assertEquals(jsonObj.getJSONObject("booking").getString("firstname"),firstName,"First Name not matching");
            Assert.assertEquals(jsonObj.getJSONObject("booking").getString("lastname"),lastName,"Last Name not matching");
            Assert.assertEquals(jsonObj.getJSONObject("booking").getBoolean("depositpaid"),depositPaid,"Deposit Paid not matching");
            Assert.assertEquals(jsonObj.getJSONObject("booking").getDouble("totalprice"),totalPrice,"Total Price not matching");
            Assert.assertEquals(jsonObj.getJSONObject("booking").getString("additionalneeds"),additionalNeeds,"Total Price not matching");

            Assert.assertEquals(jsonObj.getJSONObject("booking").getJSONObject("bookingdates").getString("checkin"),checkinDate,"Check in Date not matching");
            Assert.assertEquals(jsonObj.getJSONObject("booking").getJSONObject("bookingdates").getString("checkout"),checkoutDate,"Checkout Date not matching");

            System.out.println("Booking ID response : " + jsonObj.getString("bookingid"));

            BookingID = jsonObj.getString("bookingid");
        }
        else{
            Assert.assertTrue(false, response.asString());
        }
    }

    /**
     *
     * @Test to retrival of created booking id
     */
    @Test (dependsOnMethods = { "createBookingTest" })
    public  void getBookingTest() throws JSONException {

        System.out.println("Starting Get Booking Test");
        response = service.getBooking(BookingID);

        if (response.getStatusCode() == 200) {
            System.out.println(response.asString());

            JSONObject jsonObj = new JSONObject(response.asString());

            Assert.assertEquals(jsonObj.getString("firstname"),firstName,"First Name not matching");
            Assert.assertEquals(jsonObj.getString("lastname"),lastName,"Last Name not matching");
            Assert.assertEquals(jsonObj.getBoolean("depositpaid"),depositPaid,"Deposit Paid not matching");
            Assert.assertEquals(jsonObj.getDouble("totalprice"),totalPrice,"Total Price not matching");
            Assert.assertEquals(jsonObj.getString("additionalneeds"),additionalNeeds,"Total Price not matching");

            Assert.assertEquals(jsonObj.getJSONObject("bookingdates").getString("checkin"),checkinDate,"Check in Date not matching");
            Assert.assertEquals(jsonObj.getJSONObject("bookingdates").getString("checkout"),checkoutDate,"Checkout Date not matching");


        }
        else{
            Assert.assertTrue(false, response.asString());
        }


    }

    /**
     *
     * @Test to retrival of Token
     */

    @Test
    public void getAuthTokenTest() throws JSONException {

        response = service.getToken();

        System.out.println("Get Token Test Starts\n");
        System.out.println("response Object \n" + response.asString());

        if (response.getStatusCode() == 200) {

            JSONObject jsonObj = new JSONObject(response.asString());

            System.out.println("JSON object from response");
            System.out.println(jsonObj);
            Assert.assertEquals(jsonObj.has("token"),true,"Failed to get Booker Token");


            bookerToken = jsonObj.getString("token");
        }
        else{
            Assert.assertTrue(false, response.asString());
        }
    }

    /**
     *
     * @Test to delete the created Booking ID
     */

    @Test (dependsOnMethods = { "getAuthTokenTest" , "createBookingTest", "getBookingTest"})
    public void deleteBookingTest() throws JSONException {

        response = service.deleteBooking(BookingID,bookerToken);

        System.out.println("Delete Booking Test Starts\n");
        System.out.println("response Object \n" + response.asString());
        System.out.println("Delete Response Code \n" + response.getStatusCode());

        if (response.getStatusCode() == 201) {

                Assert.assertEquals(response.asString().trim(),"Created");
        }
        else{
            Assert.assertTrue(false, response.asString());
        }
    }


}

