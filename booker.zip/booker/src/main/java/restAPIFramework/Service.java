package restAPIFramework;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.json.JSONException;
import org.json.JSONObject;

import com.jayway.restassured.RestAssured;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;
import requestPojo.Bookingdates;
import requestPojo.CreateBooking;


public class Service {


    public String bookerURL;
    public String userName;
    public String passWord;

    /**
        getPropValues - Gets all properties from config.properties
     **/
    public void getPropValues() throws IOException
    {

        Properties prop = new Properties();
        String propFileName = "config.properties";

        InputStream inputStream = getClass().getClassLoader().getResourceAsStream(propFileName);

        if (inputStream != null)
        {
            prop.load(inputStream);
            bookerURL = prop.getProperty("BOOKER_URL");
            userName = prop.getProperty("TOKEN_USER_NAME");
            passWord = prop.getProperty("TOKEN_PASSWORD");
        }
        else
        {
            throw new FileNotFoundException("property file" + propFileName + "not found in class path");
        }

        System.out.println("Booker URL " + prop.getProperty("BOOKER_URL"));
    }

    /**
    Just to find all booking ids are returned not used in tests for now
    **/

    public Response getBookings(){
        RequestSpecification requestSpecification = RestAssured.given();
        requestSpecification.contentType("application/json");
        requestSpecification.accept("application/json");
        String getBookingsURL = bookerURL+"/booking";
        System.out.println("end point url.."+ getBookingsURL);
        Response response = requestSpecification.get(getBookingsURL);
        return response;
    }

    /**
    Pass created booking id to retrive booking details
     **/

    public Response getBooking(String bookingID){
        RequestSpecification requestSpecification = RestAssured.given();
        requestSpecification.accept("application/json");
        String getBookingsURL = bookerURL+"/booking/" + bookingID;
        System.out.println("end point url.."+ getBookingsURL);
        Response response = requestSpecification.get(getBookingsURL);
        return response;
    }

    List<JSONObject> list;

    /**
     * This API will create Booking
     * @param firstName
     * @param lastName
     * @param totalPrice
     * @param depositPaid
     * @param checkinDate
     * @param checkoutDate
     * @return
     */
    public Response createBooking(String firstName,String lastName, double totalPrice,boolean depositPaid, String checkinDate, String checkoutDate, String additionalDetails){


        CreateBooking createBooking = new CreateBooking();
        createBooking.setFirstname(firstName);
        createBooking.setLastname(lastName);
        createBooking.setTotalprice(totalPrice);
        createBooking.setDepositpaid(depositPaid);

        Bookingdates bookingdates = new Bookingdates();
        bookingdates.setCheckin(checkinDate);
        bookingdates.setCheckout(checkoutDate);

        createBooking.setBookingdates(bookingdates);
        createBooking.setAdditionalneeds(additionalDetails);

        JSONObject jsonObj = new JSONObject(createBooking);
        System.out.println("json payload..");
        list = new ArrayList<JSONObject>();
        list.add(jsonObj);


        String createBookingbody;
        createBookingbody = list.toString();
        createBookingbody = createBookingbody.replaceAll("\\[", "");
        createBookingbody = createBookingbody.replaceAll("]", "");

        System.out.println(createBookingbody);
        RequestSpecification requestSpecification = RestAssured.given();
        requestSpecification.contentType("application/json");
        requestSpecification.accept("application/json");
        requestSpecification.body(createBookingbody);
        String createBookingURL = bookerURL + "/booking";
        System.out.println("create end point url.."+createBookingURL);
        Response response = requestSpecification.post(createBookingURL);
        return response;
    }

    /**
    This is API to get Token to delete or put operations
     **/

    public Response getToken() throws JSONException
    {
        JSONObject objectCredentials = new JSONObject();
        objectCredentials.put("username" , userName);
        objectCredentials.put("password" , passWord);

        String getBookerToken = bookerURL + "/auth";

        System.out.println("User/Pass \n" + userName + " " + passWord);

        RequestSpecification requestSpecification = RestAssured.given();
        requestSpecification.contentType("application/json");
        requestSpecification.body(objectCredentials.toString());
        Response response = requestSpecification.post(getBookerToken);

        System.out.println("Get Auth token URL" + "   " + getBookerToken);

        System.out.println("User Object \n" + objectCredentials.toString());

        return response;
    }

    /**
        This is API to get delete created booking ID
     **/

    public Response deleteBooking(String bookingID, String tokenBooker) {
        RequestSpecification requestSpecification = RestAssured.given();
        requestSpecification.contentType("application/json");
        String tokenString = "token="+ tokenBooker;
        requestSpecification.header("Cookie",tokenString);
        String deleteBookingsURL = bookerURL + "/booking/" + bookingID;
        System.out.println("Delete end point url.." + deleteBookingsURL);
        Response response = requestSpecification.delete(deleteBookingsURL);
        return response;

    }

    public static void main(String[] args) throws IOException  {
        Service service = new Service();
        service.getPropValues();
    }

}
